function Ht = FIRtp(H,n)
% Lazy transpose of FIR system
% Takes [H0; H1; ... ; Hn] to [H0'; H1'; ... ;Hn']
% Each Hi is p by m
[m1, m] = size(H);
p = m1 / (n+1);
% Overloaded permute for sdpvar doesnt seem to work when m=1
if m==1
    Ht = reshape(H,[p,n+1])';
else
    Ht = cflat(permute(reshape(H,[p,n+1,m]),[3,1,2]));
end
end

