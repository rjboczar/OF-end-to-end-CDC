function [D11,D21] = setupD(dist_flag)
    if dist_flag
        % Disturbance rejection setup
        D11 = zeros(2);
        D21 = [0,1];
    else
        % Reference tracking
        D11 = [0 -1; 0 0];
        D21 = [0,-1];
    end
end

