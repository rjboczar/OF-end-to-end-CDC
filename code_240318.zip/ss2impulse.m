function [varargout] = ss2impulse(varargin)
%SS2IMPULSE Summary of this function goes here
%   Detailed explanation goes here
    maxT = 0;
    for k = 1:nargin
        [Y,~] = impulse(varargin{k});
        varargout{k} = permute(Y,[2,3,1]);
        maxT = max(maxT, size(varargout{k},3));
    end
    %Pad impulse resp with zeros
    for k = 1:nargin
        sz = size(varargout{k});
        varargout{k} = cat(3,varargout{k},...
            zeros(sz(1),sz(2),maxT-sz(3)));
    end
end

