function [T_len, T_len_norm] = ...
            FIR_approx_error(rs, num_plants, normalize, fname)
    T_len = zeros(numel(rs), num_plants);
    T_len_norm = zeros(numel(rs), num_plants);
    
    for j = 1:numel(rs)
        r = rs(j);
        fprintf('r=%d\n',r);
        % Draw random plants, coefs in [-1,1]
        current_plants = 2*rand(r,num_plants) - 1;
        current_plants_norm = zeros(r,num_plants);
        
        for k = 1:num_plants
            g = current_plants(:,k);
            G_raw = FIR2ss(g);
            % Use previous values to determine search ranges
            [lo, hi] = get_range(T_len(j,1:k-1),r);
            T_len(j,k) = bisect_int(@(T)within_tol(G_raw,T,2e-2), lo, hi);
            if normalize
                % Divide through by Hinf norm
                gam = hinfnorm(G_raw);
                current_plants_norm(:,k) = g/gam;
                G_norm = FIR2ss(g/gam);
                % Use previous values to determine search ranges
                [lo, hi] = get_range(T_len_norm(j,1:k-1),r);
                T_len_norm(j,k) = ...
                    bisect_int(@(T)within_tol(G_norm,T,2e-2), lo, hi);
            end
    
        end
        fprintf('Avg: f(r)=%.1f, f(r)(norm)=%.1f\n',...
            mean(T_len(j,:)), mean(T_len_norm(j,:)));
        % Write stuff to file
        dlmwrite(fname,[current_plants; current_plants_norm],'-append')
        dlmwrite(fname,[T_len(j,:); T_len_norm(j,:)],'-append')
    end
end

function [lo, hi] = get_range(prev_vals, r)
    if numel(prev_vals) > 0
        tgt = mean(prev_vals);
    else
        tgt = 7*r;
    end 
    lo = floor(.8*tgt);
    hi = ceil(1.2*tgt);
    assert(hi-lo>0);
end

function ok = within_tol(G,T,tol)
    [~, ~, rel_err] = ...
        approx_sls_hinf_synth(G, 0, 0, T, -1, -1, 0, 1, 1);
    ok = (rel_err <= tol);   
end

function T = bisect_int(f,lo,hi)
    %Finds the smallest integer T such that f(T) = 1
    while ~f(hi)
        fprintf('hi is too small (hi=%d)\n',hi)
        hi = round(4/3 * hi);
    end
    while f(lo)
        fprintf('lo is too large (lo=%d)\n',lo)
        lo = round(3/4 * lo);
    end
    while hi - lo > 1
        mid = ceil((hi+lo)/2);
        if f(mid)
            hi = mid;
        else
            lo = mid;
        end
    end
    T = hi;
end
    

