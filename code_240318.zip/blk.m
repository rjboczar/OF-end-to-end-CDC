function B = blk(A,p,r,c)
    % Gets r,c-th block of A (1-indexed)
    rs = 1+(r-1)*p;
    cs = 1+(c-1)*p;
    B = A(rs:(rs+p-1),cs:(cs+p-1));
end
