function B = cflat(A)
% Takes a m x n x p matrix A and stacks the pages in column order so the
% resulting matrix is m*p x n
    S = permute(A,[2,1,3]);
    B = S(:,:)';
end

