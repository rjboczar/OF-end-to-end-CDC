function [F, Q] = hinf_constraints(H, n, gamma)
% Creates an SDP matrix Q and returns it along with the relevant
% constraints F that ensure Hinf(H) <= gamma
% H is assumed to be p*(n+1) x m

[m1, m] = size(H);
p = m1 / (n+1);
% Use transposed system if necessary
if p > m
    Hbar = FIRtp(H,n);
    [m,p] = deal(p,m);
else
    Hbar = H;
end
    
Q = sdpvar(p*(n+1),p*(n+1));

F = [];
for k = 0:n
    % Sum along the kth subdiagonal
    tmp = zeros(p);
    for j = 1:(n+1-k)
        tmp = tmp + blk(Q,p,j+k,j);
    end
    % TR(Theta_pk) = gamma*I*delta(k) (Thm 5.8, eq 5.44)
    F = [F, tmp==(eye(p)*gamma*(k==0))];

end
% Toep constraints, block constraint (eq 5.45) which implies PSD constraint
F = [F, [Q, Hbar; Hbar',gamma*eye(m)]>=0];

end
    