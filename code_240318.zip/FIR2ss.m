function G = FIR2ss(g)
    % FIR column vector [g1; ... ; g_{r-1}] (g0=0) to ss form
    r = numel(g);
    G = ss(diag(ones(r-1,1),-1), eye(r,1), g', 0,1);
end

