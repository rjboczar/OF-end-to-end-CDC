function G = resp2ss(F)
% Not sure how this isnt a function
% F is a p x m x T matrix (T>1)
% Returns the system with impulse response
% 
[~, m, T] = size(F);
A = kron(diag(ones(T-2,1),-1), eye(m));
B = [eye(m); zeros((T-2)*m,m)];
C = rflat(F(:,:,2:end));
D = F(:,:,1);
G = ss(A,B,C,D,1);
end

