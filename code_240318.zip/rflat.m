function B = rflat(A)
% Takes a m x n x p matrix A and stacks the pages in row order so the
% resulting matrix is m x n*p
    B = A(:,:);
end

