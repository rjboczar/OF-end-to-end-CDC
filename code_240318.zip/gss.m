function [x, xs, fs] = gss(f,a,b,tau)
    % Golden section search for x>0
    % tau is about sqrt(eps)
    phi = (sqrt(5) + 1) / 2;
    xs = [];
    fs = [];
    
    % Make sure we picked a good range
    lo_flag = 0;
    hi_flag = 0;
    while ~(lo_flag && hi_flag)
        % Init
        a0 = a;
        b0 = b;
        c = b - (b - a) / phi;
        d = a + (b - a) / phi ;
        while abs(b - a) > tau*(abs(c) + abs(d))
%             fprintf('gss: [%.4f %.4f]\n',a,b);
            fc = f(c);
            fd = f(d);
            xs = [xs c d];
            fs = [fs fc fd];
            if fc < fd
                b = d;
                hi_flag = 1;
            else
                a = c;
                lo_flag = 1;
            end
            c = b - (b - a) / phi;
            d = a + (b - a) / phi;
        end
        % Check flags to see if we need to fix range
        if ~lo_flag
            % Started too high
            b = a0*1.25;
            a = a0/2;
            hi_flag = 0;
            warning('Started too high. [%.3f %.3f]->[%.3f %.3f]\n',...
                a0, b0, a, b);
        elseif ~hi_flag
            % Started too low
            a = b0*0.75;
            b = b0*2;
            lo_flag = 0;
            warning('Started too low. [%.3f %.3f]->[%.3f %.3f]\n',...
                a0, b0, a, b);
        end
    end
    x = (b + a) / 2;
end