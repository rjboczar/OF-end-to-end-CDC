function opts = init_opts(m,T,alphas,varargin)
   % Simulation options
   
   p = inputParser;
   % List of number of rollouts
   addRequired(p,'m');
   % FIR approx length
   addRequired(p,'T');
   % Search bounds for alpha
   addRequired(p,'alphas',@(x)length(x)==2);
   % Whether to try to predict better alpha search regions
   addOptional(p,'predict_alpha',0);
   % Output noise cov.
   addOptional(p,'sig',0.1);
   % Estimated plant length (-1 for length of g)
   addOptional(p,'r',-1);
   % Function to compute Sigms(r)
   addOptional(p,'Sigma',@(r)eye(r))
   % Verbosity level
   addOptional(p,'verbosity',0);
   % Number of trials per rollout 
   addOptional(p,'Ntrials',1);
   % Hinfinity calculation tolerance
   addOptional(p,'htol',1e-6);
   
   % CHERNOFF PROPERTIES
   addOptional(p,'sim_delta',1e-3);
   addOptional(p,'p_target',1e-2);
   addOptional(p,'n_samples',1e5);
   
   % PLANT PROPERTIES
   addOptional(p,'normalize_plant',0);
   % Plant scaling TODO
   addOptional(p,'rho',1);
   % 1 for disturbance rejection, 0 for ref tracking
   addOptional(p,'dist_flag',1);
   addOptional(p,'run_no',1);
   
   addOptional(p,'gss_tol',1e-3);
   addOptional(p,'TOLGAM',1e-4);
   addOptional(p,'mosek_threads',0);
   addOptional(p,'max_workers',72);
   
   addOptional(p,'clearN',0);

   parse(p,m,T,alphas,varargin{:});
   opts = p.Results;

end

