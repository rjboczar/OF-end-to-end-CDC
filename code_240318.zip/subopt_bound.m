function results = subopt_bound(g,opts)
    % Solves end-to-end SLS problem.
    % Inputs:
    %   g - coeffs [g1; ...; g_{r-1}] of true plant
    %   opts:
    %       see init_opts
    % Outputs:
    %   results - array of results
    
    % Unpack some things for convenience
    if opts.r == -1
        r = length(g)+1;
    else
        r = opts.r;
    end
    htol = opts.htol;
    
    results = [];
    G_nom = FIR2ss(g);
    
    % Normalize
    if opts.normalize_plant
        Hnorm = hinfnorm(G_nom,htol);
        g = g/Hnorm;
        G_nom = FIR2ss(g);
    end

    
    % 0. Solve SLS synthesis problem for true plant (alpha/beta not needed)
    disp('Solving nominal problem...')
    [resp_st, J0, ~] = fast_sls_gss(G_nom, 0, 0, opts);
    [R0, N0, M0, L0] =  deal(resp_st{:});
    fprintf('Nominal cost: %.3e\n', J0);
    for m = opts.m
        for k = 1:opts.Ntrials
            ok = 1;
            t = tic;
            % 1. Estimate g by least squares
            rollouts = zeros(r,m);
            for j = 1:m
                rollouts(:,j) = impulse(G_nom,r-1) + randn(r,1)*opts.sig;
            end
            gtilde = mean(rollouts(2:end,:),2);
            % 1.5 Get tail bound
            Cov = eye(r)*opts.sig^2/m; % for now just assume impulse TODO
            Covh = chol(Cov);
            % Don't instantiate something this big
            samples = zeros(opts.n_samples,1);
            for j = 1:opts.n_samples
                samples(j) = norm(Covh*randn(r,1));
            end
            [~, norm_eps] = estimate_tail(samples, opts.p_target, opts.sim_delta);
            % Make sure eps is small enough
            if norm_eps >= 0.5/hinfnorm(N0,htol)
                warning('eps not small enough (%f vs %f)',...
                    norm_eps, 0.5/hinfnorm(N0,htol));
                ok = 2;
                Jt = -1;
                Jhat = -1;
                bound = -1;
                alpha_st = -1;
            else
                delta = g - gtilde;
                % 2. Solve approx SLS problem with hp eps
                disp('Solving approximate problem...')
                Gtilde = FIR2ss(gtilde);
                [resp_tilde, Jt, alpha_st] = fast_sls_gss(Gtilde, norm_eps, 1, opts);
                [Rt, Nt, Mt, Lt] =  deal(resp_tilde{:});
                fprintf('Approx (tilde) cost: %.3e\n', Jt)
                % 3. Compute actual response
                Theta_hat = ...
                    [Rt Nt; Mt Lt] + 1/(1-delta'*Nt)*[Nt*delta';Lt*delta']*[Rt Nt];
                % 4. Compute actual cost
                [D11, D21] = setupD(opts.dist_flag);
                B1 = [G_nom.B zeros(size(G_nom.B))];
                Jhat = hinfnorm(blkdiag(g',1)*Theta_hat*[B1; D21]+D11,htol);
                fprintf('Actual (hat) cost: %.3e\n', Jhat)
                % 5. Compute upper bound
                bound = 2*norm_eps/(1-2*norm_eps*hinfnorm(N0,htol))...
                    *hinfnorm([1+g'*N0; L0],htol)*hinfnorm(R0*B1+N0*D21,htol);
                fprintf('Jhat-J0: %.2f, Upper bound: %.2f\n', Jhat-J0, bound)
            end
            % 6. Compute cost when designing using approx system
            [Jactual, Jexpected] = nominal_cost(G_nom, gtilde, opts);
            tm = toc(t);
            fprintf('Time: %.2fs\n', tm);
            results = [results;...
                [m, r, opts.T, opts.run_no, k,...
                J0, Jt, alpha_st, Jhat, bound, Jactual, Jexpected,...
                tm, ok]];
            fprintf('FINISHED: m:%d, r:%d, run:%d, trial:%d\n',m, r, opts.run_no, k);
        end
    end

end
