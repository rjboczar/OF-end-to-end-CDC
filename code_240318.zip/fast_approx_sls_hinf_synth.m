function [cost, Theta, rel_err] = fast_approx_sls_hinf_synth(...
    G, eps, alpha, approx, check_alpha_opt, opts)
    % Solves (approximate) SLS problem for a fixed alpha/beta.
    % Inputs:
    %   G - nominal or approximate plant (derived from (Z,e1,g') plant)
    %   rho - scaling for plant TODO
    %   eps - whp bound on ||delta||_2
    %   alpha - parameter for approximate SLS problem
    %   approx - flag to solve approximate problem (0 for nominal problem)
    %   check_alpha_opt - makes sure constraints are tight at optimum alpha
    %   opts:
    %       T - length of FIR responses to look over
    %       dist_flag - flag for disturbance rejection setup (0 for ref.
    %           tracking)
    %       verbosity - flag for solver output
    % Outputs:
    %   cost - optimal cost (Inf if infeasible)
    %   Theta - optimal {R,N,M,L} in SS form
    %   rel_err - relative hinf error (for nominal plant)
    
    % Unpack
    T = opts.T;
    dist_flag = opts.dist_flag;

    % Setup plant
    [A,B,C2,~] = ssdata(G);
    B1 = [B, zeros(size(B))];
    B2 = B;
    %TODO rho
    [D11,D21] = setupD(dist_flag);
    gtilde = C2';
    r = numel(gtilde);

    % Create filters
    yalmip('clear');
    Rt = sdpvar(r,r,T,'full');
    Nt = sdpvar(r,1,T,'full');
    Mt = sdpvar(1,r,T,'full');
    Lt = sdpvar(1,1,T,'full');
    t = sdpvar(4,1,'full');

    % SLS constraints written in a compact form
    % These enforce {R0,N0,M0}=0 as well
    I0 = [zeros(r), eye(r), zeros(r,r*(T-1))];
    Fsls = [...
        % (zI-A)R = B2*M + dkI
        [rflat(Rt),zeros(r)] - A*[zeros(r),rflat(Rt)]==...
            B2*[zeros(1,r), rflat(Mt)] + I0,...
        % (zI-A)N = B2*L
        [rflat(Nt),zeros(r,1)] - A*[zeros(r,1),rflat(Nt)]==...
            B2*[0,rflat(Lt)],...
        % R(zI-A) = NC2 + dkI
        [cflat(Rt);zeros(r)] - [zeros(r);cflat(Rt)]*A==...
            [zeros(r,1);cflat(Nt)]*C2 + I0',...
        % M(zI-A) = LC2
        [cflat(Mt);zeros(1,r)] - [zeros(1,r);cflat(Mt)]*A==...
            [0; cflat(Lt)]*C2];

    %%% Hinf constraints and objective
    % Stack responses in a column
    
    % [gt' 0; 0 1] * [R N; M L] * [B1; D21] + D11
    H1big = kron(eye(T),blkdiag(gtilde',1))*...
                cflat([Rt, Nt; Mt, Lt])*[B1; D21] + [D11; zeros(2*(T-1),2)];
    [F1, Q1] = hinf_constraints(H1big, T-1, t(1));
    if approx
        % R*B1 + N*D21
        H2big = [cflat(Rt), cflat(Nt)]*[B1; D21];
        [F2, Q2] = hinf_constraints(H2big, T-1, t(2));
        % [1 + g'*N; L]
        Nbig = vec([gtilde'*rflat(Nt)+eye(1,T); rflat(Lt)]);
        [F3, Q3] = hinf_constraints(eps*alpha*cflat(Nt), T-1, t(3));
        [F4, Q4] = hinf_constraints(Nbig, T-1, t(4));
        AllF = [Fsls,...
                F1, F2, F3, F4,...
                t(3) + t(4) == alpha,...
                t>=0];
        obj = t(1) + eps*alpha*t(2);
    else
        AllF = [Fsls, F1, t(1)>=0, t(2:4)==0];
        obj = t(1);
    end

    % Solve
    yalmip_opts = sdpsettings('dualize',1,'verbose',opts.verbosity > 1,'solver','mosek');
    yalmip_opts.mosek.MSK_IPAR_NUM_THREADS = opts.mosek_threads;
    diagnostics = optimize(AllF,obj,yalmip_opts);

    Theta = {resp2ss(value(Rt)),...
                   resp2ss(value(Nt)),...
                   resp2ss(value(Mt)),...
                   resp2ss(value(Lt))};
    tt = value(t);

    if diagnostics.problem
        cost = inf;
        if ~approx
            warning('Infeasible problem');
        end
    else
        %Make sure bounds are saturated
        btol = 1e-3;
        assert_close(...
            hinfnorm(blkdiag(gtilde',1)*...
            [Theta{1} Theta{2}; Theta{3} Theta{4}]*[B1;D21]+D11,1e-8),...
            tt(1), btol);
        if approx
            assert_close(hinfnorm(Theta{1}*B1 + Theta{2}*D21,1e-8),...
                tt(2), btol);
            % These are only guaranteed to be saturated at alpha*
            if check_alpha_opt
                assert_close(hinfnorm(Theta{2},1e-8)*eps*alpha,...
                    tt(3), btol);
                assert_close(hinfnorm([1+gtilde'*tf(Theta{2}); tf(Theta{4})],1e-8),...
                    tt(4), btol);
            end

            cost = tt(1) + eps*alpha*tt(2);
        else
            cost = tt(1);
        end
    end
    
    % Print diagnostic info
    if opts.verbosity
        fprintf('Cost: %.3f\n',cost)
    end
    
    if ~approx
        % If we are solving for the nominal model, sanity check using
        % hinfsyn to make sure T was set long enough
        C1 = [gtilde'; zeros(size(gtilde'))];
        D22 = 0;
        D12 = [0; 1];
        P = ss(A, [B1, B2], [C1; C2], [D11 D12; D21 D22], -1);
        [~,~,gamma,~] = hinfsyn(P,1,1,'TOLGAM',1e-8);
        cdiff = cost - gamma;
        rel_err = abs(cdiff)/gamma;
        if opts.verbosity
            fprintf('Cost diff: %.3f, Rel err: %.2e\n',...
                cdiff, rel_err);
        end
%             assert(rel_err <= 2e-2,...
%                 'Relative Hinf error too large, T may be too small');
    end
end
