function [Jactual, Jexpected, stable] = nominal_cost(G_nom, gtilde, opts)
        [A,B,C_nom,~] = ssdata(G_nom);
        B1 = [B, zeros(size(B))];
        B2 = B;
        %TODO rho
        [D11,D21] = setupD(opts.dist_flag);
        D22 = 0;
        D12 = [0; 1];
        D = [D11 D12; D21 D22];
        
        % Design using approx system
        C1 = [gtilde'; zeros(size(gtilde'))];
        C2 = gtilde';
        P = ss(A, [B1, B2], [C1; C2], D, -1);
        [K,CL,Jexpected,INFO] = hinfsyn(P,1,1,'TOLGAM',opts.TOLGAM);
        % Test using real
        C1 = [C_nom; zeros(size(C_nom))];
        P = ss(A, [B1, B2], [C1; C_nom], D, -1);
        Jactual = hinfnorm(lft(P,K),opts.htol);
       
end

