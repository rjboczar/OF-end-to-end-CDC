function [resp_st, cost_st, alpha_st] = ...
            fast_sls_gss(G, eps, approx, opts)
    % Solves (approximate)SLS problem for a grid of alphas and betas.
    % Inputs:
    %   G - nominal or approximate plant
    %   eps - whp bound on ||delta||_2
    %   approx - flag to solve approximate problem (0 for nominal problem)
    %   opts:
    %       T - length of FIR responses to look over
    %       alphas - [lo, hi] parameters for approximate SLS problem, uses
    %           golden section search
    %       dist_flag - flag for disturbance rejection setup (0 for ref.
    %           tracking)
    %       verbosity - flag
    %       rho - plant scaling
    % Outputs:
    %   resp_st: {R,N,M,L} of optimal response
    %   cost_st: optimal cost
    %   alpha_st: corresponding alpha

    if approx
        alphas = opts.alphas;
        [alpha_st, xs, fs] = gss(@(x)fast_approx_sls_hinf_synth(...
            G, eps, x, approx, 0, opts),...
            alphas(1),alphas(2),opts.gss_tol);
    else
        alpha_st = -1;
    end
    [cost_st, resp_st] =  fast_approx_sls_hinf_synth(...
        G, eps, alpha_st, approx, 1, opts);

    fprintf('a:%.3f J:%.3f\n', alpha_st, cost_st);
end


