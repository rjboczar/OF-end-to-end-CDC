function [p,t] = estimate_tail(samples, p_target, delta)
    % Takes a vector of samples of X and tries to
    % find a t such that P(X >= t) <= p_target with probability
    % at least 1-delta wrt the simulator

    n = numel(samples);
    % Super lazy
    lo = min(samples); hi = max(samples);
    while hi - lo > 1e-5
        t = (hi + lo)/2;
        phat = mean(samples >= t);
        p = invert_kl(phat,n,delta);
        %fprintf('X > %.4f with prob at most %f\n', t, p)
        % Quit early if you can
        if abs(p - p_target) < 1e-5
            break
        end
        if p > p_target
            lo = t;
        else
            hi = t;
        end
    end
    % Probably shouldn't get here from the while loop finishing
    assert(abs(p - p_target) < 1e-3);
    fprintf('X > %.4f with prob at most %f\n', t, p)
end

function y = kl(p,q)
    % KL divergence between two Bernoullis
    y = (1-p)*log((1-p)/(1-q)) + p*log(p/q);
end

function q = invert_kl(p, n, delta)
    % Uses Newton's method to solve log(delta) = -n * KL(p,q)

    % Check to see if equation is solvable
    assert(kl(p,1) > -log(delta)/n,...
           'Equation not solvable, increase N or delta');
    
    % Newtons method, always returns upper solution (q >= p)
    q = .999;
    for j = 1:20
        f = kl(p,q) + log(delta)/n;
        fp = (1-p)/(1-q) - p/q;
        q = q - f/fp;
    end
    err = abs(log(delta)+n*kl(p,q));
    assert(err < 1e-8,...
           'Equation did not solve to tolerance')
end

